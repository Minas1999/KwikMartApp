CREATE PROCEDURE [dbo].[Get]
as
	select * from Users
RETURN 0
go

